package state_pattern;

public class ScreenStateContext {
    ScreenState currentState;

    public void setState(ScreenState state) {
        this.currentState = state;
    }
    
    public void updateUiFromState(){
        currentState.userInterfacePrinter();
    }

    public void request(int choice) {
        currentState.handleRequest(this, choice);
    }

    
}
