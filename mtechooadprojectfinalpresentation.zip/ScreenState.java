package state_pattern;

public interface ScreenState {

    public void userInterfacePrinter();

    public void handleRequest(ScreenStateContext context, int choice);
}
