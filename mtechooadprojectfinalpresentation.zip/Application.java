import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import state_pattern.MainScreenState;
import state_pattern.ScreenStateContext;

public class Application {



    public static void main(String[] args) {
        ScreenStateContext screenStateContext = new ScreenStateContext();
        screenStateContext.setState(new MainScreenState());
        try {
            Scanner s = new Scanner(System.in);
            int choice = -1;
            do {
                clearScreen();
                screenStateContext.updateUiFromState();
                exitHelper();
                choice = s.nextInt();
                screenStateContext.request(choice);
            } while (choice != 0);
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private static void exitHelper(){
        System.out.println("\n Enter \"0\" to exit the application.\n");
    }


    public static void clearScreen(){     
        System.out.print("\033[H\033[2J");  
        System.out.flush();  
    }


}
