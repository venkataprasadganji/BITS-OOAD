package state_pattern;

public class ViewVehicleScreenState implements ScreenState {

    @Override
    public void handleRequest(ScreenStateContext context, int choice) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'choice1'");
    }

    @Override
    public void userInterfacePrinter() {
        System.out.println("************************************************************************************\r\n" + //
                        "View Vehicle (1)\r\n" + //
                        "************************************************************************************\r\n" + //
                        "Vehicle Management System - OOAD Project - Team 3\r\n" + //
                        "\r\n" + //
                        "You are purchasing <Vehicle Info HERE>\r\n" + //
                        "Vehicle Name      Model      Variant     Price     Discount    TOTAL PRICE\r\n" + //
                        "TOYOTA Canberry   V1         ALPHA       87L       50K         86.5L\r\n" + //
                        "\r\n" + //
                        "Enter your choice:\r\n" + //
                        "1. Purchase\r\n" + //
                        "2. Cancel\r\n" + //
                        "************************************************************************************");
    }
    
}

