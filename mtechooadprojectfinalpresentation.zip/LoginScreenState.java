package state_pattern;

public class LoginScreenState implements ScreenState {

    @Override
    public void handleRequest(ScreenStateContext context, int choice) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'choice1'");
    }

    @Override
    public void userInterfacePrinter() {
        System.out.println("************************************************************************************\r\n" + //
                        "Login Screen (1)\r\n" + //
                        "************************************************************************************\r\n" + //
                        "Vehicle Management System - OOAD Project - Team 3\r\n" + //
                        "\r\n" + //
                        "Enter your email:\r\n" + //
                        "Enter your password:\r\n" + //
                        "************************************************************************************");
    }
    
}

