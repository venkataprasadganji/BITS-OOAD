package state_pattern;

public class VehicleAvailableScreenState implements ScreenState {

    @Override
    public void handleRequest(ScreenStateContext context, int choice) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'choice1'");
    }

    @Override
    public void userInterfacePrinter() {
        System.out.println("************************************************************************************\r\n" + //
                        "View vehicles available (1)\r\n" + //
                        "************************************************************************************\r\n" + //
                        "Vehicle Management System - OOAD Project - Team 3\r\n" + //
                        "\r\n" + //
                        "Here are the vehicles available\r\n" + //
                        "Vehicle Name      Model      Variant     Price     Discount\r\n" + //
                        "1. XYZ1\r\n" + //
                        "2. XYZ2\r\n" + //
                        ".\r\n" + //
                        ".\r\n" + //
                        "N. XYZN\r\n" + //
                        "\r\n" + //
                        "Enter the vehicle number you would like to purchase.\r\n" + //
                        "************************************************************************************");
    }
    
}

